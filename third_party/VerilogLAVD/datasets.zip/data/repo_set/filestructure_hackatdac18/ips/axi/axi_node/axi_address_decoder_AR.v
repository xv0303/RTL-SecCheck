module axi_address_decoder_AR (
	clk,
	rst_n,
	arvalid_i,
	araddr_i,
	arready_o,
	arvalid_o,
	arready_i,
	START_ADDR_i,
	END_ADDR_i,
	enable_region_i,
	connectivity_map_i,
	incr_req_o,
	full_counter_i,
	outstanding_trans_i,
	error_req_o,
	error_gnt_i,
	sample_ardata_info_o
);
	reg _sv2v_0;
	parameter ADDR_WIDTH = 32;
	parameter N_INIT_PORT = 8;
	parameter N_REGION = 4;
	input wire clk;
	input wire rst_n;
	input wire arvalid_i;
	input wire [ADDR_WIDTH - 1:0] araddr_i;
	output reg arready_o;
	output reg [N_INIT_PORT - 1:0] arvalid_o;
	input wire [N_INIT_PORT - 1:0] arready_i;
	input wire [((N_REGION * N_INIT_PORT) * ADDR_WIDTH) - 1:0] START_ADDR_i;
	input wire [((N_REGION * N_INIT_PORT) * ADDR_WIDTH) - 1:0] END_ADDR_i;
	input wire [(N_REGION * N_INIT_PORT) - 1:0] enable_region_i;
	input wire [N_INIT_PORT - 1:0] connectivity_map_i;
	output reg incr_req_o;
	input wire full_counter_i;
	input wire outstanding_trans_i;
	output reg error_req_o;
	input wire error_gnt_i;
	output reg sample_ardata_info_o;
	wire [N_INIT_PORT - 1:0] match_region;
	wire [N_INIT_PORT:0] match_region_masked;
	wire [(N_REGION * N_INIT_PORT) - 1:0] match_region_int;
	wire [(N_INIT_PORT * N_REGION) - 1:0] match_region_rev;
	reg arready_int;
	reg [N_INIT_PORT - 1:0] arvalid_int;
	genvar _gv_i_1;
	genvar _gv_j_1;
	reg CS;
	reg NS;
	generate
		for (_gv_j_1 = 0; _gv_j_1 < N_REGION; _gv_j_1 = _gv_j_1 + 1) begin : genblk1
			localparam j = _gv_j_1;
			for (_gv_i_1 = 0; _gv_i_1 < N_INIT_PORT; _gv_i_1 = _gv_i_1 + 1) begin : genblk1
				localparam i = _gv_i_1;
				assign match_region_int[(j * N_INIT_PORT) + i] = (enable_region_i[(j * N_INIT_PORT) + i] == 1'b1 ? (araddr_i >= START_ADDR_i[((j * N_INIT_PORT) + i) * ADDR_WIDTH+:ADDR_WIDTH]) && (araddr_i <= END_ADDR_i[((j * N_INIT_PORT) + i) * ADDR_WIDTH+:ADDR_WIDTH]) : 1'b0);
			end
		end
		for (_gv_j_1 = 0; _gv_j_1 < N_INIT_PORT; _gv_j_1 = _gv_j_1 + 1) begin : genblk2
			localparam j = _gv_j_1;
			for (_gv_i_1 = 0; _gv_i_1 < N_REGION; _gv_i_1 = _gv_i_1 + 1) begin : genblk1
				localparam i = _gv_i_1;
				assign match_region_rev[(j * N_REGION) + i] = match_region_int[(i * N_INIT_PORT) + j];
			end
		end
		for (_gv_i_1 = 0; _gv_i_1 < N_INIT_PORT; _gv_i_1 = _gv_i_1 + 1) begin : genblk3
			localparam i = _gv_i_1;
			assign match_region[i] = |match_region_rev[i * N_REGION+:N_REGION];
		end
	endgenerate
	assign match_region_masked[N_INIT_PORT - 1:0] = match_region & connectivity_map_i;
	assign match_region_masked[N_INIT_PORT] = ~(|match_region_masked[N_INIT_PORT - 1:0]);
	always @(*) begin
		if (_sv2v_0)
			;
		if (arvalid_i)
			{error_req_o, arvalid_int} = {N_INIT_PORT + 1 {arvalid_i}} & match_region_masked;
		else begin
			arvalid_int = 1'sb0;
			error_req_o = 1'b0;
		end
		arready_int = |({error_gnt_i, arready_i} & match_region_masked);
	end
	always @(posedge clk or negedge rst_n)
		if (rst_n == 1'b0)
			CS <= 1'd0;
		else
			CS <= NS;
	always @(*) begin
		if (_sv2v_0)
			;
		arready_o = 1'b0;
		arvalid_o = arvalid_int;
		sample_ardata_info_o = 1'b0;
		incr_req_o = 1'b0;
		case (CS)
			1'd0:
				if (error_req_o) begin
					NS = 1'd1;
					arready_o = 1'b1;
					sample_ardata_info_o = 1'b1;
					arvalid_o = 1'sb0;
				end
				else begin
					NS = 1'd0;
					arready_o = arready_int;
					sample_ardata_info_o = 1'b0;
					incr_req_o = |(arvalid_o & arready_i);
					arvalid_o = arvalid_int;
				end
			1'd1: begin
				arready_o = 1'b0;
				arvalid_o = 1'sb0;
				if (outstanding_trans_i)
					NS = 1'd0;
				else if (error_gnt_i)
					NS = 1'd0;
				else
					NS = 1'd1;
			end
			default: begin
				NS = 1'd0;
				arready_o = arready_int;
			end
		endcase
	end
	initial _sv2v_0 = 0;
endmodule
